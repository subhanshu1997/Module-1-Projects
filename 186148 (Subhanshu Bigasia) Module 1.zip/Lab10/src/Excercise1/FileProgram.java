package Excercise1;

public class FileProgram {

	public static void main(String[] args) {
		copyDataThread cd=new copyDataThread();
		Thread t=new Thread(cd);
		t.start();

	}

}
