package Excercise2;

public class getTimer implements Runnable{

	@Override
	public void run() {
	try {
	System.out.println("Timer Started");
	for(int j=0;j<10;j++) {
	for(int i=0;i<10;i++) {
		System.out.println(i);
		Thread.sleep(1000);
	}
	}
	}catch (Exception e) {
	}	
	}

}
