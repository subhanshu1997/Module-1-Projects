package Excercise2;

public class timer {

	public static void main(String[] args) {
		getTimer gt=new getTimer();
		Thread t=new Thread(gt);
		t.start();

	}

}
