import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

public class Excercise1 extends JFrame{
	public void Demo() {
		JRadioButton jRadioButton1=new JRadioButton("Red");
		JRadioButton jRadioButton2=new JRadioButton("Yellow");
		JRadioButton jRadioButton3=new JRadioButton("Green");
		jRadioButton1.setBounds(120, 30, 120, 50);
		jRadioButton2.setBounds(125, 90, 80, 30);
		jRadioButton3.setBounds(250, 30, 80, 50);
		this.add(jRadioButton1);
		this.add(jRadioButton2);
		this.add(jRadioButton3);
		ButtonGroup bg=new ButtonGroup();
		bg.add(jRadioButton1);
		bg.add(jRadioButton2);
		bg.add(jRadioButton3);
		jRadioButton1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(jRadioButton1.isSelected()) {
					JOptionPane.showMessageDialog(Excercise1.this,"STOP");
				}	
			}
		});
			jRadioButton2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(jRadioButton2.isSelected()) {
					JOptionPane.showMessageDialog(Excercise1.this,"WAIT");
				}	
			}
		});
			jRadioButton3.addActionListener(new ActionListener() {
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		if(jRadioButton3.isSelected()) {
			JOptionPane.showMessageDialog(Excercise1.this,"GO");
		}	
	}
});
	}

	public static void main(String[] args) {
		Excercise1 ex=new Excercise1();
		ex.setBounds(100, 100, 400, 200);
		ex.setVisible(true);
		ex.Demo();

	}

}
