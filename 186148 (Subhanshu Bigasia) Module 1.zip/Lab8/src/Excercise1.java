import java.util.Scanner;
import java.util.StringTokenizer;

public class Excercise1 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Please enter numbers seperated by ,");
		String num=s.nextLine();
		StringTokenizer st=new StringTokenizer(num,",");
		int sum=0;
		while(st.hasMoreTokens()) {
			int number=Integer.parseInt(st.nextToken());
			System.out.println(number);
			sum=sum+number;
		}
		System.out.println("Sum of numbers is"+sum);

	}

}
