import java.io.File;
import java.util.Scanner;

public class Excercise4 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Please Enter File Path");
		String path=s.nextLine();
		File f=new File(path);
		if(f.exists()) {
			System.out.println("File Exist");
			if(f.canRead()) {
				System.out.println("File is Readable");
			}
			else{
				System.out.println("File is not Readable");
			}
			if(f.canWrite()) {
				System.out.println("File is writable");
			}
			else {
				System.out.println("File is not Readable");
			}
			System.out.println("Length of file is: "+f.length()+" byte");
			int index=path.indexOf('.');
			index++;
			System.out.println(index);
			StringBuffer sb=new StringBuffer();
			while(index<=path.length()-1) {
				sb.append(path.charAt(index));
				index++;
			}
			System.out.println("Type of file is: "+sb);
		}
		else {
			System.out.println("File does'nt exist");
		}

	}

}
