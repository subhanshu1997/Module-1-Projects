import java.util.Scanner;

public class Excercise7 {
	public static boolean validate(String str) {
		int count=0;
		int i=0;
			while(i<str.length() && str.charAt(i)!='_') {
				count++;
				i++;
			}
			if(count<8)
				return false;
		StringBuffer sb=new StringBuffer();
		i++;
		while(i<str.length()) {
			sb.append(str.charAt(i));
			i++;
		}
		if(!sb.toString().equals("job")) {	
			return false;
		}
		return true;
	}

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter jobseeker username");
		String str=s.nextLine();
		boolean flag=validate(str);
		if(flag==true) {
			System.out.println("Valid Username");
		}
		else
		{
			System.out.println("Invalid Username");
		}
	}

}
