import java.util.Scanner;

public class Excercise3 {

	public static void main(String[] args) {
		 int countWord = 0; 
	        int sentenceCount = 0; 
	        int characterCount = 0; 
	        int paragraphCount = 1; 
	        int whitespaceCount = 0; 
		Scanner s=new Scanner(System.in);
		System.out.println("Please enter numbers seperated by ,");
		String line=s.nextLine();
        { 
            if(!(line.equals(""))) 
            {
                characterCount += line.length(); 
                  
                // \\s+ is the space delimiter in java 
                String[] wordList = line.split("\\s+"); 
                  
                countWord += wordList.length; 
                whitespaceCount += countWord -1; 
                  
                // [!?.:]+ is the sentence delimiter in java 
                String[] sentenceList = line.split("[!?.:]+"); 
                  
                sentenceCount += sentenceList.length; 
            } 
        }

	}

}
