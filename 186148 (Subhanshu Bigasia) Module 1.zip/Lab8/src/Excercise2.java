import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Excercise2 {

	public static void main(String[] args) {
		try {
			BufferedReader reader = new BufferedReader(new FileReader(
					"D:/Users/sbigasia/Desktop/sql.txt"));
			String line = reader.readLine();
			int count=1;
			while (line != null) {
				System.out.println(count);
				System.out.println(line);
				count++;
				// read next line
				line = reader.readLine();
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
