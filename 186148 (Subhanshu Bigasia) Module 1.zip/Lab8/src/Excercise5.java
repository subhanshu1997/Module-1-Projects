import java.util.Scanner;

public class Excercise5 {
	public boolean isPositive(String s) {
		for(int i=1;i<s.length();i++) {
			if(s.charAt(i)<s.charAt(i-1)) {
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Input a string");
		String str=s.nextLine();
		Excercise5 ex=new Excercise5();
		if(ex.isPositive(str)) {
			System.out.println("String is Positive");
		}
		else {
			System.out.println("String is Negative");
		}
		

	}

}
