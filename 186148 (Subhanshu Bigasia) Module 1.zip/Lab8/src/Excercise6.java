import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;
import java.util.Scanner;

public class Excercise6 {

	public static void main(String[] args) throws ParseException {
	    Date dateNow = new Date();  
	    SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
	    String strDate= formatter.format(dateNow);  
	    System.out.println(strDate);
	    Scanner s=new Scanner(System.in);
	    String d=s.nextLine();
	    Date oldDate=formatter.parse(d);
	    LocalDate date1 = oldDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	    LocalDate date2 = dateNow.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
	    Period period=Period.between(date1,date2);
	    System.out.println(period);

}
}
