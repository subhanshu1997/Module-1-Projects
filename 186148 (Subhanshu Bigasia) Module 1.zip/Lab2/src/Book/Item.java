package Book;

public abstract class Item {
private int uid;
private String title;
private int noofcopies;
public void Item() {
	// TODO Auto-generated constructor stub
}
public int getUid() {
	return uid;
}
public void setUid(int uid) {
	this.uid = uid;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public int getNoofcopies() {
	return noofcopies;
}
@Override
public String toString() {
	return "Book [uid=" + uid + ", title=" + title + ", noofcopies=" + noofcopies + "]";
}
public void setNoofcopies(int noofcopies) {
	this.noofcopies = noofcopies;
}
@Override
	public boolean equals(Object arg0) {
		// TODO Auto-generated method stub
		return super.equals(arg0);
	}
public abstract void print();
public abstract void checkIn();
public abstract void checkOut();
public abstract void addItem();
}
