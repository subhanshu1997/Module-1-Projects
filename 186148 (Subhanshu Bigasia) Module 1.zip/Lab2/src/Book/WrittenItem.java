package Book;

public abstract class WrittenItem extends Item{
private String author="";
public String getAuthor() {
	return author;
}

public void setAuthor(String author) {
	this.author = author;
}
public abstract void print();
public abstract void checkIn();
public abstract void checkOut();
public abstract void addItem();
}
