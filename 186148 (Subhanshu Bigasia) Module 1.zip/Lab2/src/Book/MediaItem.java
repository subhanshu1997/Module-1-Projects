package Book;

public abstract class MediaItem extends Item{
private int runtime;
public abstract void print();
public abstract void checkIn();
public abstract void checkOut();
public abstract void addItem();
}
