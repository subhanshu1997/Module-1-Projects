package excercise1;

public interface getPower {
void power(int x,int y);
}
