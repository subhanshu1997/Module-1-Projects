package excercise4;

import java.util.Scanner;

interface Interface1 {
	void show(String a,String b);
}
class Class2{
	public void getDetails(String firstname,String lastname) {
		System.out.println("Your first name is: "+firstname);
		System.out.println("Your last name is: "+lastname);
	}
}
public class Class3 {
	public static void main(String[] args) {
		Class2 c=new Class2();
		Scanner s=new Scanner(System.in);
		System.out.println("Enter first Name");
		String firstName=s.nextLine();
		System.out.println("Enter last Name");
		String lastName=s.nextLine();
		Interface1 i=c::getDetails;
		i.show(firstName,lastName);

	}

}
