import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class Excercise2 {
	public static void count(char[] c) {
		HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		for(int i=0;i<c.length;i++) {
			if(!hm.containsKey(c[i])) {
				hm.put(c[i],1);
			}
			else {
				hm.put(c[i],hm.get(c[i])+1);
			}
		}
		for(Character character:hm.keySet()) {
			System.out.println(character+" occured "+hm.get(character)+" times.");
		}
	}

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the numbe of characters");
		int num=s.nextInt();
		char[] ch=new char[num];
		for(int i=0;i<num;i++) {
			char character=s.next().charAt(0);
			ch[i]=character;
		}
		count(ch);

	}

}
