package com.cg.eis.pl;

import java.util.regex.Pattern;

public class test {

	public static void main(String[] args) {
		System.out.println(Pattern.matches("[A-Z]*","Helloworld"));

	}

}
