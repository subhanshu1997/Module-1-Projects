import java.util.Arrays;
import java.util.Scanner;

public class Excercise2 {
public String[] sort(String[] a,int n) {
	Arrays.sort(a);
	if(n%2==0) {
		for(int i=0;i<=(n/2)-1;i++) {
			a[i]=a[i].toUpperCase();
		}
		for(int i=n/2;i<n;i++) {
			a[i]=a[i].toLowerCase();
		}
	}
	else {
		for(int i=0;i<=n/2;i++) {
			a[i]=a[i].toUpperCase();
		}
		for(int i=n/2+1;i<n;i++) {
			a[i]=a[i].toLowerCase();
		}
	}
//	for(int i=0;i<n;i++) {
//		System.out.println(a[i]);
//	}
	return a;
}
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number strings");
		int n=s.nextInt();
		String[] a=new String[n];
		for(int i=0;i<n;i++) {
			System.out.println("Enter the String to be inserted");
			a[i]=s.next();
		}
		Excercise2 ex=new Excercise2();
		a=ex.sort(a, n);
		for(int i=0;i<n;i++) {
			System.out.println(a[i]);
		}
	}

	}
