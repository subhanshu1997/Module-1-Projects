import java.util.Arrays;
import java.util.Scanner;

public class Excercise3 {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number of elements in array");
		int n=s.nextInt();
		int[] a=new int[n];
		for(int i=0;i<n;i++) {
			System.out.println("Enter the number to be inserted");
			a[i]=s.nextInt();
		}
		for(int i=0;i<n;i++) {
			String st=Integer.toString(a[i]);
			StringBuffer sb=new StringBuffer(st);
			sb.reverse();
			a[i]=Integer.parseInt(sb.toString());
		}
		Arrays.sort(a);
		for(int i=0;i<n;i++) {
			System.out.println(a[i]);
		}
	}
}
