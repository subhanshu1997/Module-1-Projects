import java.util.HashMap;
import java.util.Scanner;

public class Excercise4 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number of characters");
		int n=s.nextInt();
		Character[] a=new Character[n];
		for(int i=0;i<n;i++) {
			System.out.println("Enter the Character to be inserted");
			a[i]=s.next().charAt(0);
		}
		HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
		for(int i=0;i<n;i++) {
			if(hm.containsKey(a[i])==false) {
				hm.put(a[i],1);
			}
			else {
				int val=hm.get(a[i]);
				hm.put(a[i],val+1);
			}
		}
		for(Character ch:hm.keySet()) {
			System.out.println(ch+" occured "+hm.get(ch)+" times");
		}
	}

}
