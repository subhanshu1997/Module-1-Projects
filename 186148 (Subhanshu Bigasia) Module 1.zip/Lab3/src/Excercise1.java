import java.util.Arrays;
import java.util.Scanner;

public class Excercise1 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the number of elements in array");
		int n=s.nextInt();
		int[] a=new int[n];
		for(int i=0;i<n;i++) {
			System.out.println("Enter the number to be inserted");
			a[i]=s.nextInt();
		}
		Arrays.sort(a);
		System.out.println("Second Smallest Number is "+a[1]);
	}

}
