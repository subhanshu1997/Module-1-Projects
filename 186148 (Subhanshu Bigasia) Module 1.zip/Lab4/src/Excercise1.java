import java.util.Scanner;

public class Excercise1 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter the Number");
		int n=s.nextInt();
		int sum=0;
		while(n/10!=0) {
			sum=sum+((n%10)*(n%10)*(n%10));
			n=n/10;
		}
		sum=sum+((n%10)*(n%10)*(n%10));
	System.out.println("Sum of cubes of digit of number is: "+sum);	
	}

}
