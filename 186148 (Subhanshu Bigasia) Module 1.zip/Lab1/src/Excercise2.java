import java.util.Scanner;

public class Excercise2 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Please input Number");
		int n=s.nextInt();
		int sum1=0,sum2=0;
		for(int i=1;i<=n;i++) {
			sum1=sum1+(i*i);
			sum2=sum2+i;
		}
		sum2=sum2*sum2;
		System.out.println("Difference is"+Math.abs(sum1-sum2));
	}

}
