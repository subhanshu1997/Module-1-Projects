import java.util.Scanner;

public class Excercise3 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Please input Number");
		int n=s.nextInt();
		String a=Integer.toString(n);
		for(int i=1;i<a.length();i++) {
			if(Character.getNumericValue(a.charAt(i))<Character.getNumericValue(a.charAt(i-1))) {
				System.out.println("Non-Increasing");
				return;
			}
		}
		System.out.println("Increasing Number");
	}

}
