import java.util.Scanner;

public class Excercise1 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("Please input Number");
		int n=s.nextInt();
		int sum=0;
		for(int i=1;i<=n;i++) {
			if(i%3==0 || i%5==0) {
				sum=sum+i;
			}
		}
		System.out.println("Sum of numbers is"+sum);

	}

}
